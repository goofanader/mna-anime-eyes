How to start:
You'll probably want to go into fullscreen: press 'f' to do so. Then, press ']' when you're ready to begin.

How to run:
Press ']' when someone gets the image correct. It'll show the image in its true glory. Press ']' again to continue to the next image.

If nobody gets the image by the time it's clear, press ']' to go the next image.

Controls:
f - enter/exit fullscreen for the monitor the program's located on
] - makes the image clear. press again to go to the next image
esc or q - quit the game

Notes:
* This version is hardcoded to have a beginning pixel size of 70
* This version is hardcoded to have a time limit of 15 seconds per image