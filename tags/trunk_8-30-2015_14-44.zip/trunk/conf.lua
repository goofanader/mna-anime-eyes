function love.conf(t)
   t.identity = "MnA_Anime_Eyes"
   t.version = "0.9.1"
   t.console = true
   t.window.title = "Anime Eyes"
   t.window.width = 800
   t.window.height = 600
   t.window.minwidth = 400
   t.window.minheight = 300
   t.window.resizable = true
end